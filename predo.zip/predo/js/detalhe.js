const API_KEY = "a3fda9b9d1d0aaee95df37313c16684e";
const BASE_URL = "https://api.themoviedb.org/3";
const IMAGE_URL = "https://image.tmdb.org/t/p/w500";

const detalhesContainer = document.getElementById("detalhesContainer");

const params = new URLSearchParams(window.location.search);
const id = params.get("id");
const type = params.get("type");

async function carregarDetalhes() {
    if (!id || !type) {
        detalhesContainer.innerHTML = "<p>Conteúdo Inválido.</p>";
        return;
    }
    try {
        const response = await fetch(
            `${BASE_URL}/${type}/${id}?api_key=${API_KEY}&language=pt-br`
        );
        if (!response.ok) {
            throw new Error("Erro n API");
        }
        const data = await response.json();
        renderizarDetalhes(data);
    } catch (error) {
        detalhesContainer.innerHTML = "<p>Error ao carregar detalhes.</p>";
        console.error(error);
    }
}
window.addEventListener("load", function() {
    const loader = document.getElementById("loader");
    if (loader) {
        loader.style.display = "pacity 0.5s ease";
        loader.style.opacity = "0";
        setTimeout(() => {
            loader.style.display = "none";
        }, 500);
    }
});

function renderizarDetalhes(item) {
    const imagem = item.poster_path
    ? IMAGE_URL + item.poster_path
    : "";
    const titulo = item.title || item.name;
    const dataLancamento = item.release_date || item.first_air_date;
    document.title = titulo;
    detalhesContainer.innerHTML = `
    <div class="detalhesContainer">
        <div class="detalhes-imagem">
        <img src="${imagem}" alt="${titulo}">
        </div>
        <div class="detalhes">
            <h2>${titulo}</h2>
            <p>Data: ${dataLancamento || "Não disponível"}
            <br>Nota: ${item.vote_average}<br>
        </div>
    </div>
    `;
}
document.addEventListener("DOMContentLoaded", carregarDetalhes);
botaoTema.addEventListener("click", () => {
    document.body.classList.toggle("tema-claro");
});